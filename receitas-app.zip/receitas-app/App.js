import React, { useState } from 'react';
import {
 Text,
 View,
 Button,
 StyleSheet,
 Modal,
 TouchableOpacity,
 TextInput,
 Alert,
 FlatList
} from 'react-native';


export default function App() {
 // Lista com as receitas cadastradas
 const [listaReceitas, setListaReceitas] = useState([
   {
     id: '1',
     nome: '🍰 Bolo de Cenoura',
     ingredientes: '• 3 cenouras médias\n• 4 ovos e 1 xícara de óleo\n• 2 xícaras de açúcar\n• 2 e 1/2 xícaras de farinha de trigo\n• 1 colher (sopa) de fermento',
     modoPreparo: 'Bata no liquidificador as cenouras, os ovos e o óleo. Em uma tigela, misture com o açúcar e a farinha. Adicione o fermento por último e asse por 40 minutos.'
   }
 ]);


 // Estados para controlar o Modal de Visualização
 const [verReceitaVisivel, setVerReceitaVisivel] = useState(false);
 const [receitaSelecionada, setReceitaSelecionada] = useState(null);


 // Estados para controlar o Modal de Cadastro/Edição e seus campos
 const [cadastroVisivel, setCadastroVisivel] = useState(false);
 const [idEdicao, setIdEdicao] = useState(null); // null = Cadastro | id = Edição
 const [nomeReceita, setNomeReceita] = useState('');
 const [ingredientes, setIngredientes] = useState('');
 const [modoPreparo, setModoPreparo] = useState('');


 // Função para salvar (cadastrar nova ou atualizar existente)
 const handleSalvar = () => {
   if (!nomeReceita.trim() || !ingredientes.trim() || !modoPreparo.trim()) {
     Alert.alert('Atenção', 'Por favor, preencha todos os campos!');
     return;
   }


   if (idEdicao) {
     // ✏️ Requisito: Edição de receitas via .map()
     const listaAtualizada = listaReceitas.map((item) => {
       if (item.id === idEdicao) {
         return {
           ...item,
           nome: nomeReceita,
           ingredientes: ingredientes,
           modoPreparo: modoPreparo,
         };
       }
       return item;
     });
     setListaReceitas(listaAtualizada);
     Alert.alert('Sucesso', `Receita "${nomeReceita}" atualizada com sucesso!`);
   } else {
     // 📝 Novo Cadastro
     const novaReceita = {
       id: Date.now().toString(),
       nome: nomeReceita,
       ingredientes: ingredientes,
       modoPreparo: modoPreparo,
     };
     setListaReceitas([...listaReceitas, novaReceita]);
     Alert.alert('Sucesso', `Receita "${nomeReceita}" cadastrada com sucesso!`);
   }


   limparEFechar();
 };


 // Função para carregar os dados de uma receita no formulário e abrir o modal
 const handleIniciarEdicao = (receita) => {
   setIdEdicao(receita.id);
   setNomeReceita(receita.nome);
   setIngredientes(receita.ingredientes);
   setModoPreparo(receita.modoPreparo);


   setVerReceitaVisivel(false);
   setCadastroVisivel(true);
 };


 // 🗑️ Requisito: Exclusão de receitas via .filter()
 const handleExcluir = (id) => {
   Alert.alert(
     'Confirmar Exclusão',
     'Tem certeza que deseja excluir esta receita?',
     [
       { text: 'Cancelar', style: 'cancel' },
       {
         text: 'Excluir',
         style: 'destructive',
         onPress: () => {
           setListaReceitas(listaReceitas.filter((item) => item.id !== id));
           setVerReceitaVisivel(false);
         }
       }
     ]
   );
 };


 // Função para cancelar a ação sem salvar
 const handleCancelar = () => {
   limparEFechar();
   
 };


 // Função auxiliar para resetar o formulário e fechar o modal
 const limparEFechar = () => {
   setNomeReceita('');
   setIngredientes('');
   setModoPreparo('');
   setIdEdicao(null);
   setCadastroVisivel(false);
 };


 // Função para abrir os detalhes de uma receita
 const abrirReceita = (receita) => {
   setReceitaSelecionada(receita);
   setVerReceitaVisivel(true);
 };
 


 return (
   <View style={styles.container}>
     {/* Cabeçalho */}
     <Text style={styles.title}>📱 App de Receitas</Text>
     <Text style={styles.subtitle}>Gerenciamento de Fluxo Completo</Text>


     {/* 🔄 Requisito: Substituição do ScrollView por FlatList + Empty State */}
     <FlatList
       data={listaReceitas}
       keyExtractor={(item) => item.id}
       renderItem={({ item }) => (
         <View style={styles.card}>
           <Text style={styles.cardTitle}>{item.nome}</Text>


           <View style={styles.cardActions}>
             <View style={styles.cardButtonWrapper}>
               <Button
                 title="Ver"
                 onPress={() => abrirReceita(item)}
                 color="#D35400"
               />
             </View>
             <View style={styles.cardButtonWrapper}>
               <Button
                 title="Editar"
                 onPress={() => handleIniciarEdicao(item)}
                 color="#F39C12"
               />
             </View>
             <View style={styles.cardButtonWrapper}>
               <Button
                 title="Excluir"
                 onPress={() => handleExcluir(item.id)}
                 color="#C0392B"
               />
             </View>
           </View>
         </View>
       )}
       // 📭 Requisito: Estado de Lista Vazia (Empty State)
       ListEmptyComponent={
         <View style={styles.emptyContainer}>
           <Text style={styles.emptyTitle}>📖 Nenhuma receita cadastrada</Text>
           <Text style={styles.emptySubtext}>
             Toque no botão "+" abaixo para adicionar a sua primeira receita!
           </Text>
         </View>
       }
       style={styles.scrollList}
       contentContainerStyle={styles.scrollContent}
     />


     {/* Modal 1: Visualização da Receita */}
     <Modal
       visible={verReceitaVisivel}
       animationType="slide"
       transparent={true}
       onRequestClose={() => setVerReceitaVisivel(false)}
     >
       <View style={styles.modalOverlay}>
         <View style={styles.modalContent}>
           {receitaSelecionada && (
             <>
               <Text style={styles.recipeTitle}>{receitaSelecionada.nome}</Text>
              
               <Text style={styles.sectionTitle}>Ingredientes:</Text>
               <Text style={styles.recipeText}>{receitaSelecionada.ingredientes}</Text>


               <Text style={styles.sectionTitle}>Modo de Preparo:</Text>
               <Text style={styles.recipeText}>{receitaSelecionada.modoPreparo}</Text>


               <View style={styles.buttonRow}>
                 <View style={styles.buttonWrapper}>
                   <Button
                     title="Editar"
                     onPress={() => handleIniciarEdicao(receitaSelecionada)}
                     color="#F39C12"
                   />
                 </View>
                 <View style={styles.buttonWrapper}>
                   <Button
                     title="Excluir"
                     onPress={() => handleExcluir(receitaSelecionada.id)}
                     color="#C0392B"
                   />
                 </View>
                 <View style={styles.buttonWrapper}>
                   <Button
                     title="Fechar"
                     onPress={() => setVerReceitaVisivel(false)}
                     color="#7F8C8D"
                   />
                 </View>
               </View>
             </>
           )}
         </View>
       </View>
     </Modal>


     {/* Botão Flutuante - FAB */}
     <TouchableOpacity
       style={styles.fab}
       onPress={() => {
         limparEFechar();
         setCadastroVisivel(true);
       }}
       activeOpacity={0.8}
     >
       <Text style={styles.fabText}>+</Text>
     </TouchableOpacity>


     {/* Modal 2: Cadastro e Edição de Receita */}
     <Modal
       visible={cadastroVisivel}
       animationType="slide"
       transparent={true}
       onRequestClose={handleCancelar}
     >
       <View style={styles.modalOverlay}>
         <View style={styles.modalContent}>
           <Text style={styles.recipeTitle}>
             {idEdicao ? '✏️ Editar Receita' : '📝 Cadastrar Receita'}
           </Text>


           {/* Nome da Receita */}
           <Text style={styles.inputLabel}>Nome da Receita:</Text>
           <TextInput
             style={styles.input}
             placeholder="Ex: Torta de Frango"
             value={nomeReceita}
             onChangeText={setNomeReceita}
             onChangeText={(texto) => setNomeReceita(formatarIniciais(texto))}
             autoCapitalize="words" returnKeyType="next" e placeholder="Ex: Torta de Frango Especial"
           />


           {/* Ingredientes */}
           <Text style={styles.inputLabel}>Ingredientes:</Text>
           <TextInput
             style={[styles.input, styles.textArea]}
             placeholder="Ex: 500g de frango, 2 xícaras de farinha..."
             value={ingredientes}
             onChangeText={setIngredientes}
             multiline={true}
             numberOfLines={3}
             onChangeText={(texto) => setIngredientes(formatarFrases(texto))} e onChangeText={(texto) => setModoPreparo(formatarFrases(texto))}
autoCapitalize="sentences" multiline={true} numberOfLines={3} e placeholders com exemplos

           />


           {/* Modo de Preparo */}
           <Text style={styles.inputLabel}>Modo de Preparo:</Text>
           <TextInput
             style={[styles.input, styles.textArea]}
             placeholder="Ex: Misture os ingredientes e asse por 30min..."
             value={modoPreparo}
             onChangeText={setModoPreparo}
             multiline={true}
             numberOfLines={3}
             onChangeText={(texto) => setIngredientes(formatarFrases(texto))} e onChangeText={(texto) => setModoPreparo(formatarFrases(texto))}
            autoCapitalize="sentences" multiline={true} numberOfLines={3} e placeholders com exemplos

           />


           {/* Botões Salvar/Atualizar e Cancelar */}
           <View style={styles.buttonRow}>
             <View style={styles.buttonWrapper}>
               <Button title="Cancelar" onPress={handleCancelar} color="#7F8C8D" />
             </View>
             <View style={styles.buttonWrapper}>
               <Button
                 title={idEdicao ? 'Atualizar' : 'Salvar'}
                 onPress={handleSalvar}
                 color="#D35400"
               />
             </View>
           </View>
         </View>
       </View>
     </Modal>
   </View>
 );
}


const styles = StyleSheet.create({
 container: {
   flex: 1,
   paddingTop: 50,
   backgroundColor: '#FAF3E0'
 },
 title: {
   fontSize: 26,
   fontWeight: 'bold',
   color: '#D35400',
   textAlign: 'center',
   marginBottom: 4
 },
 subtitle: {
   fontSize: 15,
   color: '#7F8C8D',
   textAlign: 'center',
   marginBottom: 16
 },
 scrollList: {
   flex: 1,
   width: '100%',
   paddingHorizontal: 20,
 },
 scrollContent: {
   paddingBottom: 90,
 },
 card: {
   backgroundColor: '#FFFFFF',
   borderRadius: 10,
   padding: 16,
   marginBottom: 12,
   elevation: 2,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: 1 },
   shadowOpacity: 0.1,
   shadowRadius: 2,
 },
 cardTitle: {
   fontSize: 18,
   fontWeight: 'bold',
   color: '#2C3E50',
   marginBottom: 12,
 },
 cardActions: {
   flexDirection: 'row',
   justifyContent: 'space-between',
 },
 cardButtonWrapper: {
   flex: 1,
   marginHorizontal: 2,
 },
 emptyContainer: {
   padding: 30,
   alignItems: 'center',
   justifyContent: 'center',
   backgroundColor: '#FFFFFF',
   borderRadius: 10,
   marginTop: 20,
 },
 emptyTitle: {
   fontSize: 16,
   fontWeight: 'bold',
   color: '#7F8C8D',
   marginBottom: 6,
 },
 emptySubtext: {
   fontSize: 13,
   color: '#BDC3C7',
   textAlign: 'center',
 },
 modalOverlay: {
   flex: 1,
   backgroundColor: 'rgba(0, 0, 0, 0.5)',
   justifyContent: 'center',
   alignItems: 'center',
   padding: 20
 },
 modalContent: {
   backgroundColor: '#FFFFFF',
   borderRadius: 12,
   padding: 20,
   width: '100%',
   elevation: 5,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: 2 },
   shadowOpacity: 0.25,
   shadowRadius: 4
 },
 recipeTitle: {
   fontSize: 22,
   fontWeight: 'bold',
   color: '#D35400',
   marginBottom: 12,
   textAlign: 'center'
 },
 sectionTitle: {
   fontSize: 16,
   fontWeight: 'bold',
   color: '#2C3E50',
   marginTop: 8,
   marginBottom: 4
 },
 recipeText: {
   fontSize: 14,
   color: '#555555',
   lineHeight: 20,
   marginBottom: 12
 },
 fab: {
   position: 'absolute',
   bottom: 24,
   right: 24,
   width: 60,
   height: 60,
   borderRadius: 30,
   backgroundColor: '#D35400',
   justifyContent: 'center',
   alignItems: 'center',
   elevation: 5,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: 2 },
   shadowOpacity: 0.3,
   shadowRadius: 3,
 },
 fabText: {
   color: '#FFFFFF',
   fontSize: 32,
   fontWeight: 'bold',
   marginTop: -2
 },
 inputLabel: {
   fontSize: 14,
   fontWeight: 'bold',
   color: '#2C3E50',
   marginBottom: 4,
   marginTop: 6
 },
 input: {
   borderWidth: 1,
   borderColor: '#BDC3C7',
   borderRadius: 6,
   paddingHorizontal: 10,
   paddingVertical: 8,
   fontSize: 14,
   backgroundColor: '#FAFAFA',
   marginBottom: 8
 },
 textArea: {
   height: 60,
   textAlignVertical: 'top'
 },
 buttonRow: {
   flexDirection: 'row',
   justifyContent: 'space-between',
   marginTop: 12
 },
 buttonWrapper: {
   flex: 1,
   marginHorizontal: 3
 }
});

